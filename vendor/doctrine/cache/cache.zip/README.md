# Doctrine Cache

[![Build Status](https://secure.travis-ci.org/doctrine/cache.png?branch=master)](http://travis-ci.org/doctrine/cache) 
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/doctrine/cache/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/doctrine/cache/?branch=master) 
[![Code Coverage](https://scrutinizer-ci.com/g/doctrine/cache/badges/coverage.png?b=master)](https://scrutinizer-ci.com/g/doctrine/cache/?branch=master)

[![Latest Stable Version](https://poser.pugx.org/doctrine/cache/v/stable.png)](https://packagist.org/packages/doctrine/cache) [![Total Downloads](https://poser.pugx.org/doctrine/cache/downloads.png)](https://packagist.org/packages/doctrine/cache)

Cache component extracted from the Doctrine Common project. [Documentation](http://doctrine-orm.readthedocs.io/projects/doctrine-orm/en/latest/reference/caching.html)
