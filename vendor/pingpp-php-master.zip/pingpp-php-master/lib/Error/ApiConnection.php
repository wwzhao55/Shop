<?php

namespace Pingpp\Error;

class ApiConnection extends Base
{
}
