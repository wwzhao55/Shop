<?php

namespace Pingpp\Error;

class Authentication extends Base
{
}
