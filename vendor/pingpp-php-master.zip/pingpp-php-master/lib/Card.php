<?php

namespace Pingpp;

class Card extends Source
{

}